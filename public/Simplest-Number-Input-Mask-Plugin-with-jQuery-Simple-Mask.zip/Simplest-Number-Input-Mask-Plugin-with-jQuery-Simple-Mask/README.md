jQuerySimpleMask
================

Simple and fast number input masks
